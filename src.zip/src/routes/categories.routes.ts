import { Request, Response, Router } from "express";

import { CategoriesRepository } from "../modules/cars/repositories/categories/CategoriesRepository";
import { CreateCategoryService } from "../modules/cars/services/categories/CreateCategoryService";

const categoriesRoutes = Router();
const categoriesRepository = new CategoriesRepository();

// create new category
categoriesRoutes.post("/", (req: Request, res: Response) => {
    const { name, description } = req.body;

    const createCategoryServive = new CreateCategoryService(
        categoriesRepository
    );

    createCategoryServive.execute({ name, description });

    return res.status(201).send();
});

// list all categories
categoriesRoutes.get("/list", (req: Request, res: Response) => {
    const all = categoriesRepository.list();

    return res.status(201).json(all);
});

export { categoriesRoutes };
